---
name: Use this template!
about: Question from Coursera?
title: ''
labels: ''
assignees: ''

---

This is NOT the place to ask questions about the material or your issues with assignments from the Coursera course.

If you have a question or an issue, use the Coursera forum to ask that. (BUT FIRST, check the FAQ for the course: https://github.com/jhu-ep-coursera/fullstack-course4/blob/master/FAQ.md) Make the question as detailed as possible so people don't have to ask you for more details before answering your question.

Questions posted here as issues will simply be closed.
